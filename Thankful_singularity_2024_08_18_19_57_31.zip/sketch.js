function setup() {
  createCanvas(400, 400);
}

function draw() {
  fill(0000);
  background(00078);
  
  rect(20, 20, 10, 10);
  ellipse(50, 50, 50, 50);
}